        

        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a class="active-menu" href="index.php"><i class="fa fa-dashboard"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="users.php"><i class="fa fa-user"></i> Users</a>
                    </li>
                    <li>
                        <a href="pops.php"><i class="fa fa-credit-card"></i> Proof of Payment</a>
                    </li>
                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->