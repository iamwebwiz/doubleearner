<?php
require("header.php");
require("sidebar.php");
?>

<div id="page-wrapper">
	<div id="page-inner">
		<h1 class="page-header">Administrator's Profile</h1>

		<div class="row">
			<div class="col-md-12">
				<p><b>Username: </b></p>
				<p><b>Phone number: </b></p>
				<p><b>E-mail: </b></p>
				<p><b>Bank: </b></p>
				<p><b>Account name: </b></p>
				<p><b>Account number: </b></p>
				<hr>
				<p><b>Joined DoubleEarners about: </b></p>
				<p><b>Donations made: </b></p>
				<p><b>Referral Bonus: </b></p>
				<p><b>Donations received: </b></p>
			</div>
		</div>
	</div>
</div>

<?php require("footer.php"); ?>