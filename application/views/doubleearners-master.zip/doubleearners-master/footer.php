	</div>

	<footer class="well" style="margin-bottom: 0">
		&copy; 2017 DoubleEarners
	</footer>

<script src="assets/js/bootstrap.js"></script>
</body>
</html>